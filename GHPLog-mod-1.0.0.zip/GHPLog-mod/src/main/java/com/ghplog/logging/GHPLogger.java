package com.ghplog.logging;

import com.ghplog.GHPHex;
import java.io.BufferedWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Logging facade used by the whole mod.
 *
 * <p>Every message is first encoded to uppercase hexadecimal via
 * {@link GHPHex#encode(String)} and only the encoded form is written:
 * <ul>
 *   <li>to {@code logs/GHPLog-encrypted.log} (the dedicated encrypted log file
 *       that can be handed to an AI together with {@code GHPLog.md});</li>
 *   <li>to the standard SLF4J log stream as a {@code [HEX]} line, so modules
 *       writing to console / {@code latest.log} also never see the plain text.</li>
 * </ul>
 *
 * <p>Line format of the encrypted log file:
 * {@code [yyyy-MM-dd HH:mm:ss.SSS][LEVEL] HEX-MESSAGE}</p>
 */
public final class GHPLogger {

	private static final Logger LOGGER = LoggerFactory.getLogger("ghplog");
	private static final DateTimeFormatter TIMESTAMP = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");
	private static final Object FILE_LOCK = new Object();

	private static Path encryptedLogPath;
	private static boolean initialized = false;

	private GHPLogger() {
	}

	/**
	 * Must be called once (from {@code GHPLogMod.onInitialize}) with the game
	 * instance directory. Prepares {@code logs/GHPLog-encrypted.log}.
	 */
	public static void init(Path gameDir) {
		synchronized (FILE_LOCK) {
			if (initialized) {
				return;
			}
			try {
				Path logsDir = gameDir.resolve("logs");
				Files.createDirectories(logsDir);
				encryptedLogPath = logsDir.resolve("GHPLog-encrypted.log");
				Files.writeString(encryptedLogPath,
						"# GHPLog encrypted log (hex-encoded) - created " + timestamp() + "\n",
						StandardCharsets.UTF_8,
						StandardOpenOption.CREATE,
						StandardOpenOption.APPEND);
			} catch (Exception e) {
				encryptedLogPath = null;
				LOGGER.error("GHPLog failed to open encrypted log file", e);
			}
			initialized = true;
		}
	}

	public static void info(String message) {
		log("INFO", message);
	}

	public static void warn(String message) {
		log("WARN", message);
	}

	public static void error(String message) {
		log("ERROR", message);
	}

	public static void error(String message, Throwable t) {
		log("ERROR", message + System.lineSeparator() + stackTraceToString(t));
	}

	/** Returns the path of the encrypted log file, or null if not initialized / failed. */
	public static Path encryptedLogPath() {
		return encryptedLogPath;
	}

	private static void log(String level, String message) {
		String encrypted = GHPHex.encode(message);
		String line = "[" + timestamp() + "][" + level + "] " + encrypted;

		writeFile(line);
		mirrorToStandardLog(level, "[HEX] " + encrypted);
	}

	private static void writeFile(String line) {
		if (encryptedLogPath == null) {
			return;
		}
		synchronized (FILE_LOCK) {
			try (BufferedWriter writer = Files.newBufferedWriter(encryptedLogPath,
					StandardCharsets.UTF_8,
					StandardOpenOption.CREATE,
					StandardOpenOption.APPEND)) {
				writer.write(line);
				writer.newLine();
			} catch (Exception e) {
				LOGGER.error("GHPLog failed to append to encrypted log file", e);
			}
		}
	}

	private static void mirrorToStandardLog(String level, String hexLine) {
		switch (level) {
			case "WARN" -> LOGGER.warn(hexLine);
			case "ERROR" -> LOGGER.error(hexLine);
			default -> LOGGER.info(hexLine);
		}
	}

	private static String timestamp() {
		return LocalDateTime.now().format(TIMESTAMP);
	}

	private static String stackTraceToString(Throwable t) {
		java.io.StringWriter sw = new java.io.StringWriter();
		t.printStackTrace(new java.io.PrintWriter(sw));
		return sw.toString();
	}
}