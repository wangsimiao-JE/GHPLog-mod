package com.ghplog;

import com.ghplog.logging.GHPLogger;
import com.ghplog.prompt.GHPLogPrompt;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.loader.api.FabricLoader;

/**
 * GHPLog - a Minecraft Fabric mod that encrypts mod log messages into
 * hexadecimal before writing them to the log file.
 *
 * <p>On initialization this mod:
 * <ol>
 *   <li>Starts the hex-encoded logger (plain text never appears in the log).</li>
 *   <li>Creates a markdown prompt file {@code GHPLog.md} at the game instance
 *       root directory, which contains the instructions an AI needs to decode
 *       the encrypted logs (skipped if the file / a folder with the same name
 *       already exists).</li>
 * </ol>
 *
 * <p>Targets Minecraft 26.1.2 with Fabric Loader &gt;= 0.19.5, Java &gt;= 25.</p>
 */
public class GHPLogMod implements ModInitializer {

	public static final String MOD_ID = "ghplog";

	@Override
	public void onInitialize() {
		GHPLogger.init(FabricLoader.getInstance().getGameDir());
		GHPLogger.info("GHPLog initializing for instance " + FabricLoader.getInstance().getGameDir());

		GHPLogPrompt.create(FabricLoader.getInstance().getGameDir());

		GHPLogger.info("GHPLog ready. Log messages are hex-encoded. Send GHPLog.md to your AI first, then send logs/GHPLog-encrypted.log.");
	}
}