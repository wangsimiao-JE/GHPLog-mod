package com.ghplog;

/**
 * Utility for encoding/decoding text to and from hexadecimal strings.
 *
 * <p>Every log message produced by GHPLog is first encoded with
 * {@link #encode(String)} (UTF-8 bytes -&gt; uppercase hex) before being
 * written to the log file, so that the plain text never appears directly
 * in the log file.</p>
 */
public final class GHPHex {

	private GHPHex() {
	}

	private static final char[] HEX_CHARS = "0123456789ABCDEF".toCharArray();

	/**
	 * Encodes the given text (UTF-8) into an uppercase hexadecimal string.
	 *
	 * @param text the plain text
	 * @return the hexadecimal representation, or null if text is null
	 */
	public static String encode(String text) {
		if (text == null) {
			return null;
		}
		byte[] bytes = text.getBytes(java.nio.charset.StandardCharsets.UTF_8);
		char[] out = new char[bytes.length * 2];
		for (int i = 0; i < bytes.length; i++) {
			int b = bytes[i] & 0xFF;
			out[i * 2] = HEX_CHARS[b >>> 4];
			out[i * 2 + 1] = HEX_CHARS[b & 0x0F];
		}
		return new String(out);
	}

	/**
	 * Decodes a hexadecimal string back into UTF-8 text.
	 *
	 * @param hex the hexadecimal string
	 * @return the decoded text, or null if hex is null
	 * @throws IllegalArgumentException if the hex string is malformed
	 */
	public static String decode(String hex) {
		if (hex == null) {
			return null;
		}
		String cleaned = hex;
		StringBuilder filtered = new StringBuilder(cleaned.length());
		for (int i = 0; i < cleaned.length(); i++) {
			char c = cleaned.charAt(i);
			if (Character.digit(c, 16) >= 0) {
				filtered.append(c);
			}
		}
		String digits = filtered.toString();
		if ((digits.length() & 1) == 1) {
			throw new IllegalArgumentException("Hex string has odd length: " + hex);
		}
		byte[] bytes = new byte[digits.length() / 2];
		for (int i = 0; i < bytes.length; i++) {
			int hi = Character.digit(digits.charAt(i * 2), 16);
			int lo = Character.digit(digits.charAt(i * 2 + 1), 16);
			bytes[i] = (byte) ((hi << 4) | lo);
		}
		return new String(bytes, java.nio.charset.StandardCharsets.UTF_8);
	}
}