package com.ghplog.prompt;

import com.ghplog.logging.GHPLogger;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

/**
 * Creates the AI parsing prompt file at the game instance root directory.
 *
 * <p>The prompt file is named {@code GHPLog.md} and contains only the
 * instructions an AI needs in order to decode the hex-encoded log
 * ({@code logs/GHPLog-encrypted.log}) back into readable text, numbers and
 * special symbols.</p>
 *
 * <p>Creation is skipped when the game instance root already contains a file
 * named {@code GHPLog.md} or a folder named {@code GHPLog}: the mod never
 * overwrites existing files.</p>
 */
public final class GHPLogPrompt {

	private static final String PROMPT_RESOURCE = "/GHPLogPrompt.md";
	private static final String PROMPT_FILE_NAME = "GHPLog.md";

	private GHPLogPrompt() {
	}

	/**
	 * Creates {@code GHPLog.md} in the given game instance directory if it
	 * does not already exist (and no {@code GHPLog} folder exists either).
	 *
	 * @param gameDir the game instance root directory
	 * @return the created prompt file path, or null if skipped / failed
	 */
	public static Path create(Path gameDir) {
		try {
			Path root = gameDir.toAbsolutePath();
			Path target = root.resolve(PROMPT_FILE_NAME);
			Path folderConflict = root.resolve("GHPLog");

			if (Files.exists(target) || Files.isDirectory(folderConflict)) {
				GHPLogger.warn("GHPLog prompt already exists at " + target
						+ " (or a GHPLog folder is present); skipping creation to avoid overwriting.");
				return null;
			}

			try (InputStream in = GHPLogPrompt.class.getResourceAsStream(PROMPT_RESOURCE)) {
				if (in == null) {
					GHPLogger.error("Prompt template resource not found: " + PROMPT_RESOURCE);
					return null;
				}
				Files.copy(in, target, StandardCopyOption.REPLACE_EXISTING);
			}
			GHPLogger.info("Created AI prompt file at " + target);
			return target;
		} catch (Exception e) {
			GHPLogger.error("Failed to create GHPLog.md prompt file", e);
			return null;
		}
	}
}