# GHPLog

适用于 **Minecraft 26.1.2 / Fabric Loader 0.19.5（Java 25+）** 的日志加密模组。

模组将所有日志消息在写出前先转换为 **16 进制（Hexadecimal）**，因此明文永远不会直接出现在日志文件中；同时会在游戏实例根目录生成 `GHPLog.md`（Markdown 格式的 AI 解析提示词），供排障时引导 AI 解码加密日志。

## 功能

1. **日志加密输出**
   - 所有经 `GHPLogger` 输出的日志消息，先通过 `GHPHex.encode` 转为大写十六进制字符串。
   - 加密日志追加写入 `logs/GHPLog-encrypted.log`，行格式：`[yyyy-MM-dd HH:mm:ss.SSS][级别] HEX消息`。
   - 同时以 `[HEX] …` 前缀镜像到标准日志流（控制台 / `latest.log`），保证任何位置都看不到明文。

2. **AI 解析提示词**
   - 模组初始化时，在**游戏实例根目录**创建 `GHPLog.md`。
   - 文件内容仅为 AI 解析提示词：说明 16 进制编码规则、解码方法、常见对照表（数字/字母/特殊符号）与排障步骤。
   - **若根目录已存在同名文件 `GHPLog.md`，或已存在名为 `GHPLog` 的文件夹，则不重复创建**（不会覆盖已有文件）。

3. **排障使用流程**
   1. 先把 `GHPLog.md`（提示词）发送给 AI；
   2. AI 确认理解后，再把 `logs/GHPLog-encrypted.log`（加密日志）发送给 AI；
   3. AI 按提示词中的规则解码十六进制内容并给出分析。

## 环境要求

| 项目 | 版本 |
| --- | --- |
| Minecraft | 26.1.2 |
| Fabric Loader | >= 0.19.5 |
| Java | >= 25 |
| Fabric API | 不需要（仅使用 Fabric Loader API） |

## 构建

```bash
# 需要 JDK 25，Gradle 由 wrapper 提供（9.7.1）
./gradlew build
```

构建产物位于 `build/libs/GHPLog-mod-<version>.jar`（同时产出源码 jar 与 LICENSE 打包）。

## 安装

1. 安装 [Fabric Loader](https://fabricmc.net/use/)（支持 Minecraft 26.1.2 的版本，如 0.19.5+）。
2. 将构建出的 `GHPLog-mod-1.0.0.jar` 放入游戏实例的 `mods/` 目录。
3. 启动游戏实例。

启动后：

- `logs/GHPLog-encrypted.log` — 十六进制加密日志（每次追加写入）；
- 游戏实例根目录 `GHPLog.md` — 生成的 AI 解析提示词（已存在则跳过）。

## 解码规则（摘要）

- 原始文本按 UTF-8 转字节，每字节两个大写十六进制字符，如 `Hello` → `48656C6C6F`。
- 每两个十六进制字符为一组，转十进制字节后按 UTF-8 解码还原文本。
- 详细规则、示例与 ASCII 对照表见 `GHPLog.md`。

## 项目结构

```
GHPLog-mod/
├── build.gradle                  # Gradle / Loom 构建配置
├── gradle.properties             # 版本参数（MC 26.1.2 / Loader 0.19.5 / Loom 1.18-SNAPSHOT）
├── settings.gradle
├── LICENSE                       # MIT 许可证
├── README.md
└── src/main/
    ├── java/com/ghplog/
    │   ├── GHPLogMod.java        # 模组入口（ModInitializer）
    │   ├── GHPHex.java           # 16 进制编解码工具
    │   ├── logging/GHPLogger.java# 日志加密输出门面
    │   └── prompt/GHPLogPrompt.java # GHPLog.md 提示词文件生成
    └── resources/
        ├── GHPLogPrompt.md       # 提示词模板资源
        └── fabric.mod.json       # Fabric 模组元数据
```

## 许可证

[MIT](LICENSE)